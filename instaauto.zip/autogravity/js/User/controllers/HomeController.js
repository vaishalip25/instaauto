angular.module('UserApp').controller('HomeController', ['$rootScope', '$scope','$sce','settings','$http','$localStorage','$window','$location','$templateCache','$stateParams','$state', function($rootScope, $scope, $sce,settings,$http,$localStorage,$window,$location,$templateCache,$stateParams,$state) {
    $scope.$on('$viewContentLoaded', function() {	
        // initialize core components
        App.initAjax();
		
		  $.get("https://ipinfo.io", function(response) {
			    $scope.user_country=response.country;
			    if($scope.user_country!=undefined){
				   get_make($scope.user_country);
				   console.log($scope.user_country);	
				}
			   
			}, "jsonp");
	 
	   function get_make(usercountry){
		   if(usercountry=='AU'){
		     usercountry='AUS';
		   }
			$scope.makeview=true;
			$http.post("User/Home_Controller/get_make?country="+usercountry).success(function(res){
				console.log(res)
			    $scope.make=res;
	         });
			 
			 $http.post("User/Home_Controller/get_featuredmake?country="+usercountry).success(function(res){
				console.log(res);
			  $scope.femake=res;
	         });
		}	
	
		$scope.getmodels=function(model)
		{
			$state.go('made', {makeid : model});
		}
    });

    // set sidebar closed and body solid layout mode
    $rootScope.settings.layout.pageContentWhite = true;
    $rootScope.settings.layout.pageBodySolid = false;
    $rootScope.settings.layout.pageSidebarClosed = false;
}]);


