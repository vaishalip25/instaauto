angular.module('UserApp').controller('MadeController', ['$rootScope','$scope','$sce','settings','$cookies','$cookieStore','$http','$window','$location','$templateCache','$stateParams','$state', function($rootScope, $scope, $sce,settings,$cookies,$cookieStore,$http,$window,$location,$templateCache,$stateParams,$state) {
    $scope.$on('$viewContentLoaded', function() {	
        // initialize core components
        App.initAjax();
		$window.scrollTo(0, 0);
		
		$cookies.makeid=$stateParams.makeid;
		if($cookies.makeid != null){
			$cookies.put('makeid', $stateParams.makeid);
			var makeid=$cookies.get('makeid');
			
		}else{
		
			var makeid=$cookies.get('makeid');
		} 
	
		
		getmodels(makeid)
		function getmodels(makeid)
		{
			$http.post('User/Home_Controller/getmodels?info='+makeid).success(function(res){
				console.log(res);
				 $scope.modelselct=res;
			});

		}

	$scope.select_trim=function(make,model)
	{
		$state.go('trim', {make : make,model : model});
	}
	
	$scope.back_make=function()
	{
			window.history.back();
	}
		
    });

    // set sidebar closed and body solid layout mode
    $rootScope.settings.layout.pageContentWhite = true;
    $rootScope.settings.layout.pageBodySolid = false;
    $rootScope.settings.layout.pageSidebarClosed = false;
}]);


