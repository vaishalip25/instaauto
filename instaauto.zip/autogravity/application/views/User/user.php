<!DOCTYPE html>
<html data-ng-app="UserApp" xmlns="http://www.w3.org/1999/xhtml"
      xmlns:fb="http://ogp.me/ns/fb#">
	  
<head>

<meta charset="utf-8">
 
<meta name="viewport" content="width=device-width, initial-scale=1">


<link href="<?php echo base_url();?>css/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
 <link href="<?php echo base_url();?>css/frontcss/style.css" rel="stylesheet" />
 <link href="<?php echo base_url();?>css/frontcss/responsive.css" rel="stylesheet" /> 
 <link rel='stylesheet' href='<?php echo base_url();?>css/frontcss/material.cyan-light_blue.min.css'>
 <link href="<?php echo base_url();?>css/css/datepicker.css" rel="stylesheet" type="text/css" />
 <link href="<?php echo base_url();?>calculator.css" rel="stylesheet" type="text/css" />
 <link rel='stylesheet' href='<?php echo base_url(); ?>css/fonts.css'>
	  <link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css'>

	  
</head>

<body>

<div>
<div data-ng-include="'<?php echo base_url();?>template/User/header.html'" data-ng-controller="HeaderController" ></div>
	
<div ui-view class="fade-in-up"></div>
</div>

</div>

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url();?>assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url();?>assets/js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
		<script src="<?php echo base_url();?>assets/custom/js/bootstrap-datepicker.js"></script>
	
		
        <script src="<?php echo base_url()?>assets/global/plugins/angularjs/angular.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url()?>assets/global/plugins/angularjs/angular-sanitize.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url()?>assets/global/plugins/angularjs/angular-touch.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url()?>assets/global/plugins/angularjs/plugins/angular-ui-router.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url()?>assets/global/plugins/angularjs/plugins/ocLazyLoad.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url()?>assets/global/plugins/angularjs/plugins/ui-bootstrap-tpls.min.js" type="text/javascript"></script>
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/ng-meta/0.3.9/ngMeta.js"></script>
		<script src="http://cdnjs.cloudflare.com/ajax/libs/angular-ui-utils/0.1.1/angular-ui-utils.min.js"></script>
        <script src="<?php echo base_url()?>js/User/user.js" type="text/javascript"></script>
       
        <script src='<?php echo base_url()?>assets/ngInfiniteScroll-1.0.0/build/ng-infinite-scroll.min.js' type='text/javascript'></script>
		
		<script src="<?php echo base_url()?>assets/global/scripts/app.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url()?>assets/layouts/layout/scripts/layout.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url()?>assets/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url()?>assets/layouts/layout/scripts/demo.min.js" type="text/javascript"></script>
		<script src="<?php echo base_url()?>assets/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.4.0/angular-cookies.js"></script>

		<script src="<?php echo base_url();?>assets/custom/js/bootstrap.offcanvas.js"></script>
	
		<script src="<?php echo base_url();?>assets/custom/js/theia-sticky-sidebar.js"></script>
		
		<script src="<?php echo base_url();?>assets/custom/js/enscroll-0.6.1.min.js"></script>
		<script src="<?php echo base_url();?>assets/custom/js/wow.js"></script>
   
	<script src="<?php echo base_url();?>assets/js/material.min.js"></script>
	
      <script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.4.7/angular-animate.min.js" ></script>
     <script src="https://mgcrea.github.io/angular-strap/dist/angular-strap.js" data-semver="v2.3.8"></script>
    <script src="https://mgcrea.github.io/angular-strap/dist/angular-strap.tpl.js" data-semver="v2.3.8"></script>
	 <script type="text/javascript" src="https://cdn.jsdelivr.net/ngstorage/0.3.6/ngStorage.min.js"></script>

<script src='https://maps.googleapis.com/maps/api/js?key=AIzaSyAd1xMYT1bt99qtFWQEzXiRBvORDWHgPtk&libraries=places'></script>
	
	<script src='https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js'></script>		
	<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.0.0-beta.2.4/assets/owl.carousel.min.css'> 
	<script src='https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.0.0-beta.2.4/owl.carousel.min.js'></script>
	<script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/1.0.2/Chart.min.js'></script>
	
	<script src="<?php echo base_url() ?>assets/ng-idle-develop/angular-idle.js" type="text/javascript"></script>
	
	</body>
</html>